import { Component } from '@angular/core'; 
import {AppModule} from './app-module'; 
import { FormsModule } from '@angular/forms'; 
@Component({ 
selector: 'app-root', 
standalone: true, 
imports: [FormsModule], 
templateUrl: './app.html' 
}) 
export class App { 
num1: number = 0; 
num2: number = 0; 
sum: number = 0; 
difference: number = 0; 
product: number = 0; 
remainder: number = 0; 
calculate() { 
this.sum = this.num1 + this.num2; 
this.difference = this.num1 - this.num2; 
this.product = this.num1 * this.num2; 
this.remainder = this.num1 % this.num2; 
} 
} 