//app-module.ts
import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule, provideClientHydration, withEventReplay } from
'@angular/platform-browser';
import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { TableViewComponent } from './table-view/table-view';
import { ListViewComponent } from './list-view/list-view';
import { EmployeeService } from './employee';
@NgModule({
 declarations: [
 App,
 TableViewComponent,
 ListViewComponent
 ],
 imports: [
 BrowserModule
 ],
 providers: [EmployeeService],
 bootstrap: [App]
})
export class AppModule { }