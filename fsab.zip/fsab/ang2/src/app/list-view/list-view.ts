import { Component } from '@angular/core';
import { EmployeeService } from '../employee';
@Component({
 selector: 'app-list-view',
 standalone: false,
 templateUrl: './list-view.html',
 styleUrl: './list-view.css',
})
export class ListViewComponent {
 employees: any[] = [];
 constructor(private empService: EmployeeService) {
 this.employees = this.empService.getEmployees();
 }
}