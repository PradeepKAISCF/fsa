import { Injectable } from '@angular/core';
@Injectable({
 providedIn: 'root'
})
export class EmployeeService {
 private employees = [
 { empno: 101, name: 'John', salary: 50000 },
 { empno: 102, name: 'Priya', salary: 60000 },
 { empno: 103, name: 'Arun', salary: 55000 },
 { empno: 104, name: 'Meena', salary: 65000 }
 ];
 constructor() { }
 getEmployees() {
 return this.employees;
 }
}