import { Component } from '@angular/core';
import { EmployeeService } from '../employee';
@Component({
 selector: 'app-table-view',
 standalone: false,
 templateUrl: './table-view.html',
 styleUrl: './table-view.css',
})
export class TableViewComponent {
 employees: any[] = [];
 constructor(private empService: EmployeeService) {
 this.employees = this.empService.getEmployees();
 }
}
