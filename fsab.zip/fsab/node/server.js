const express = require('express'); 
const session = require('express-session'); 
const bodyParser = require('body-parser'); 
const path = require('path'); 
const app = express(); 
const PORT = 3000; 
// Middleware 
app.use(bodyParser.urlencoded({ extended: true })); 
app.use(express.static('public')); 
app.use( 
session({ 
secret: 'studentsecret', 
resave: false, 
saveUninitialized: true 
}) 
); 
app.set('view engine', 'ejs'); 
// Hardcoded credentials 
const validUser = { 
regno: '22BCE1001', 
password: 'vit123', 
name: 'Catherine', 
parent: 'Sandhya', 
email: 'catherine@vit.ac.in' 
}; 
// Route to fetch login page 
app.get('/', (req, res) => { 
res.render('login'); 
}); 
// Validate login 
app.post('/login', (req, res) => { 
  const { regno, password } = req.body; 
 
  if ( 
    regno === validUser.regno && 
    password === validUser.password 
  ) { 
    req.session.title = 'VITian'; 
    req.session.regno = regno; 
 
    res.render('home', { 
      regno: regno, 
      title: req.session.title 
    }); 
  } else { 
    res.send('<h1>Invalid Credentials</h1>'); 
  } 
}); 
 
// Personal page route 
app.get('/personal', (req, res) => { 
  if (!req.session.regno) { 
    return res.redirect('/'); 
  } 
 
  res.render('personal', validUser); 
}); 
// Total calculation route 
app.get('/calc', (req, res) => { 
if (!req.session.regno) { 
return res.redirect('/'); 
} 
const mark1 = parseInt(req.query.mark1); 
const mark2 = parseInt(req.query.mark2); 
const total = mark1 + mark2; 
res.render('total', { total }); 
}); 
// Logout route 
app.get('/logout', (req, res) => { 
req.session.destroy(() => { 
res.redirect('/'); 
}); 
}); 
app.listen(PORT, () => { 
console.log('Server running at http://localhost:${PORT}'); 
});